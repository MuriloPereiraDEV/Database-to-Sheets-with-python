from __future__ import print_function
from operator import index
from bancoDeDados import bancoSql
import pandas as pd
import time
import os.path
import schedule
import json

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

# SE MUDAR O ESCOPO, APAGAR ARQUIVO TOKEN.JSON
SCOPES = ['https://www.googleapis.com/auth/spreadsheets']

# ID e Range da Planilha
SAMPLE_SPREADSHEET_ID = '1SQpEutNB-UwFEB0O6V_yIWOnOTynkfjCVnA7tKKxdTY'
SAMPLE_RANGE_NAME = 'Página1!A1:G'


def main():
    creds = None
    
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    #Validação de Credenciais
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'client_secret.json', SCOPES)
            creds = flow.run_local_server(port=0)
        # Save the credentials for the next run
        with open('token.json', 'w') as token:
            token.write(creds.to_json())

    service = build('sheets', 'v4', credentials=creds)

    #Pega arquivo inteiro
    sheet = service.spreadsheets()
    #Lê a planilha
    result = sheet.values().get(spreadsheetId=SAMPLE_SPREADSHEET_ID,
                                range=SAMPLE_RANGE_NAME).execute()

    #Pega os valores
    values = result.get('values', [])

    valuesDF = pd.DataFrame(values)

    dados = bancoSql()

    dados['datadopagamento'] = dados['datadopagamento'].fillna("vazio")
    dados['codigo'] = dados['codigo'].fillna("vazio")
    dados['fornecedorrelatorio'] = dados['fornecedorrelatorio'].fillna("vazio")
    dados['CPFCNPJ'] = dados['CPFCNPJ'].fillna("vazio")
    dados['itemDeDespesa'] = dados['itemDeDespesa'].fillna("vazio")
    dados['projetorelatorio'] = dados['projetorelatorio'].fillna("vazio")
    dados['valordasolicitacao'] = dados['valordasolicitacao'].fillna("vazio")

    if len(valuesDF)==0:
        header = [
            ['datadopagamento', 'codigo', 'fornecedorrelatorio', 'CPFCNPJ', 'itemDeDespesa', 'projetorelatorio', 'valordasolicitacao']
        ]
        sheet.values().update(spreadsheetId=SAMPLE_SPREADSHEET_ID,
                                   range='Página1!A1', valueInputOption="USER_ENTERED", body={"values":header}).execute()
    print(dados.shape[0])
    print(len(valuesDF))
    print(dados)
    #Verifica se a planilha está de acordo com o banco 
    if len(dados)==(len(valuesDF)-1):
        print("Já está atualizada!")
    else:
        rangeAux = dados.shape[0] - (len(valuesDF))
        sizeValuesDF = len(valuesDF)
        for i in range(rangeAux):
            indexAux = sizeValuesDF + i
            string = str(sizeValuesDF+ i + 1)
            print(indexAux)
            
            valores_adicionar = [
                dados.iloc[indexAux].tolist()
            ]
    
            #Adiciona ou edita valores
            sheet.values().update(spreadsheetId=SAMPLE_SPREADSHEET_ID,
                                   range='Página1!A'+string, valueInputOption="USER_ENTERED", body={"values":valores_adicionar}).execute()
            time.sleep(2)
        print("Nova Atualização!")

schedule.every(1).seconds.do(main)

while 1:
    schedule.run_pending()
    time.sleep(1)